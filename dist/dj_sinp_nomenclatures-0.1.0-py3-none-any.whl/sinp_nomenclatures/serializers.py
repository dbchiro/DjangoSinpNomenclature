from rest_framework.serializers import ModelSerializer
from .models import (
    NomenclatureSource,
    NomenclatureType,
    NomenclatureItem,
)


class NomenclatureItemSerializer(ModelSerializer):
    class Meta:
        model = NomenclatureItem
        fields = ["id", "code", "mnemonic", "label", "type"]


class NomenclatureTypeSerializer(ModelSerializer):
    class Meta:
        model = NomenclatureType
        fields = ["id", "code", "mnemonic", "label"]


class NomenclatureSourceSerializer(ModelSerializer):
    class Meta:
        model = NomenclatureSource
        fields = ["id", "name", "version"]
