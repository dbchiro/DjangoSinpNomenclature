from django.urls import path

from .views import (
    NomenclatureItemViewset,
    NomenclatureSourceViewset,
    NomenclatureTypeViewset,
)


app_name = "sinp_nomenclatures"

urlpatterns = [
    path(
        "nomenclature/sources",
        NomenclatureSourceViewset.as_view({"get": "list"}),
        name="source_list",
    ),
    path(
        "nomenclature/source/<int:pk>",
        NomenclatureSourceViewset.as_view({"get": "retrieve"}),
        name="source",
    ),
    path(
        "nomenclature/types",
        NomenclatureTypeViewset.as_view({"get": "list"}),
        name="type_list",
    ),
    path(
        "nomenclature/type/<int:pk>",
        NomenclatureTypeViewset.as_view({"get": "retrieve"}),
        name="type",
    ),
    path(
        "nomenclature/type/<int:pk>/items",
        NomenclatureTypeViewset.as_view({"get": "list"}),
        name="item_list",
    ),
    # path("nomenclature/type/<int:pk>/item/<int:pk>",NomenclatureTypeViewset.as_view({"get":"list"}), name="item_list"),
]
