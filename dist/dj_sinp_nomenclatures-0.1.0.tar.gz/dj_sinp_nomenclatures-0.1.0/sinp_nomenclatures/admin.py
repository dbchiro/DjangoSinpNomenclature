from django.contrib import admin

# Register your models here.
from .models import (
    NomenclatureItem,
    NomenclatureType,
    NomenclatureSource,
)


class NomenclatureItemAdmin(admin.ModelAdmin):
    list_display = ("id", "type", "code", "label", "active")
    list_filter = ("type", "active")


# Register your models here.
admin.site.register(NomenclatureItem, NomenclatureItemAdmin)
admin.site.register(NomenclatureType)
admin.site.register(NomenclatureSource)

