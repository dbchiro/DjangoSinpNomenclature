import logging

# from django.contrib.auth.mixins import LoginRequiredMixin
from rest_framework.permissions import IsAuthenticated
from rest_framework.viewsets import ReadOnlyModelViewSet

from .models import NomenclatureItem, NomenclatureSource, NomenclatureType
from .serializers import NomenclatureItemSerializer, NomenclatureSourceSerializer, NomenclatureTypeSerializer

logger = logging.getLogger(__name__)


class NomenclatureItemViewset(ReadOnlyModelViewSet):
    serializer_class = NomenclatureItemSerializer
    permission_classes = [IsAuthenticated]
    queryset = NomenclatureItem.objects.all()

class NomenclatureTypeViewset(ReadOnlyModelViewSet):
    serializer_class = NomenclatureTypeSerializer
    permission_classes = [IsAuthenticated]
    queryset = NomenclatureType.objects.all()

class NomenclatureSourceViewset(ReadOnlyModelViewSet):
    serializer_class = NomenclatureSourceSerializer
    permission_classes = [IsAuthenticated]
    queryset = NomenclatureSource.objects.all()


# Create your views here.
